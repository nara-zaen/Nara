const menuButton = document.querySelector('.menu-button');
const menuList = document.querySelector('.menu-list');
const contents = document.querySelectorAll('.content');

menuButton.addEventListener('click', () => {
    menuList.classList.toggle('show');
});

menuList.addEventListener('click', (event) => {
    if (event.target.tagName === 'BUTTON') {
        event.preventDefault();
        const contentId = event.target.dataset.content;
        contents.forEach(content => content.classList.remove('show'));
        document.getElementById(contentId).classList.add('show');
        menuList.classList.remove('show');
    }
});
        
const copyright = document.querySelector('.copyright');

let isCopyrightVisible = true;
let touchTimer;

document.addEventListener('touchstart', () => {
    clearTimeout(touchTimer); // Batalkan timer jika ada sentuhan baru
    if (isCopyrightVisible) {
        copyright.style.opacity = '0';
        isCopyrightVisible = false;
    }
});

document.addEventListener('touchend', () => {
    touchTimer = setTimeout(() => {
        if (!isCopyrightVisible) {
            copyright.style.opacity = '1';
            isCopyrightVisible = true;
        }
    }, 1000); // Munculkan setelah 2 detik tanpa sentuhan
});
